export default function Loading() {
    return(
        <p>Fetching data...</p>
    )
}